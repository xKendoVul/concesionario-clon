// import React from "react";
"use client";

import { useForm } from "react-hook-form";

import { useRouter } from "next/navigation";
import { CarData } from "../../interfaces/car.interface";
import { Label } from "../ui/label";
import { Input } from "../ui/input";
import { Button, buttonVariants } from "../ui/button";
import { addCar } from "@/app/api/cars.api";

export const metadata = {
  title: "Agregar Marca",
  description: "Agregar una nueva marca al sistema",
};

export function CarForm() {
  const { register, handleSubmit } = useForm<CarData>();
  const router = useRouter();

  const onSubmit = handleSubmit(async (data) => {
    console.log(data);
    await addCar(data);
    router.push("/dashboard/brands");
    router.refresh();
  });

  return (
    <form onSubmit={onSubmit}>
      <Label>Modelo</Label>
      <Input {...register("name")} />
      <Label>Descripción</Label>
      <Input {...register("description")} />
      <Label>Año</Label>
      <Input {...register("description")} />
      <Label>Precio</Label>
      <Input {...register("description")} />
      <Label>Disponibilidad</Label>
      {/* <Input {...register("description")} /> */}
      <select>
        <option value="true">Si</option>
        <option value="false">No</option>
      </select>

      <Button className={buttonVariants({ variant: "agregar" })}>
        Agregar Marca
      </Button>
    </form>
  );
}

export default BrandForm;
